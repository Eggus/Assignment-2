﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2_phase_1
{

    public partial class Form1 : Form
    {
    
       
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Car car1 = new Car();
            Car car2 = new Car();
            car2.make = "Holden";
            car2.model = "Commodore";
            car2.year = 1997;
            car2.cost = 3000;
            Car car3 = new Car();
            car3.make = "BMW";
            car3.model = "Hatch sport line";
            car3.year = 2022;
            car3.cost = 57700;
            listBox1.Text = car1.make.ToString();
            MessageBox.Show("the car model is " + car1.model.ToString() + " and the make is " + car1.year.ToString());
            // LAB 6 PART 2 FOR LISTBOX 
        }   
    }
}

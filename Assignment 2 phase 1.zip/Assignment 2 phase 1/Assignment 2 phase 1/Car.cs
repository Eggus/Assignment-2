﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_phase_1
{
    public class Car
    {
        public string make;
        public string model;
        public double year;
        public double cost;

        public Car()
        {
            make = "Suzuki";
            model = "Aerio";
            year = 2011;
            cost = 7000;
        }
    
        public void CalcGST()
        {
            double gst;
            double GSTcost;
            gst = cost * 0.15;
            GSTcost = cost * 1.15;
        }

    }
}
